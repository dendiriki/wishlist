<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-header text-center">
                My Artikel
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('artikelredaktur.add')); ?>" class="btn btn-primary">Add Artikel</a>
                <br />
                <br />
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Artikel</th>
                            <th>Tanggal Submit</th>
                            <th>Status</th>
                            <th>Keterangan</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if($a->artikelstatus[0]->id_status == 3): ?>
                                        <a href="<?php echo e(route('artikelredaktur.edit', ['id' => $a->id, 'id_artikel' => $a->artikelstatus[0]->id_artikel])); ?>"
                                            style="color: #000;"><?php echo e($a->judul); ?></a>
                                    <?php else: ?>
                                        <?php echo e($a->judul); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($a->updated_at); ?></td>
                                <td>
                                    <?php if(isset($a->artikelstatus[0])): ?>
                                        <?php echo e($a->artikelstatus[0]->status->statuses); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php echo e($a->keterangan); ?>

                                </td>
                                <td>
                                    <?php if($a->artikelstatus[0]->id_status == 3): ?>
                                        <a href="<?php echo e(route('artikelredaktur.edit', ['id' => $a->id, 'id_artikel' => $a->artikelstatus[0]->id_artikel])); ?>"
                                            class="btn btn-warning">Edit</a>
                                    <?php else: ?>
                                        <a href="#" class="btn btn-secondary">Edit</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/redaktur/myartikel.blade.php ENDPATH**/ ?>