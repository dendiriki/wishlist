<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-header text-center">
                Publish
            </div>
            <div class="card-body">
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Judul Artikel</th>
                            <th>Tanggal Submit</th>
                            <th>Tanggal Publish</th>
                            <th>Penulis</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $artikelstatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td> <?php if(isset($a->artikel)): ?>
                                        <?php echo e($a->artikel->judul); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php if(isset($a->artikel)): ?>
                                        <?php echo e($a->artikel->updated_at); ?>

                                    <?php endif; ?></td>
                                </td>
                                <td><?php echo e($a->updated_at); ?></td>

                                <td>
                                    <?php if(isset($a->artikel)): ?>
                                        <?php echo e($a->artikel->user->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php if(isset($a->artikel)): ?>
                                        <?php echo e($a->artikel->keterangan); ?>

                                    <?php endif; ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/jurnalis/publish.blade.php ENDPATH**/ ?>