<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mt-5">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header" style="text-align:center"><?php echo e(__('My Profil')); ?></div>
                    <div class="card-body">
                        <br />

                        <form method="post" action="<?php echo e(route('profil.update', ['id' => $users->id])); ?>"
                            enctype="multipart/form-data">

                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>



                            <div class="col">
                                <img src="<?php echo e($users->foto != '' ? asset('uploads/' . $users->foto) : asset('assets/images/cowok-removebg-preview.png')); ?>"
                                    style="border: 1px solid #000000; width: 150px; height: 150px; overflow: hidden; border-radius: 50%; object-fit: cover; margin-left:265px;" />
                                <br />
                                <br />
                                <input type="file" style="margin-left:245px" name="foto">

                            </div>

                            <br />
                            <br />
                            <div class="row mb-3">
                            <div class="col-md-6 col">
                                <label>Nama</label>
                                <input type="text" name="name" class=" form-control" value="<?php echo e($users->name); ?>">

                                <?php if($errors->has('name')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('name')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>


                            <div class="col-md-6 col">
                                <label>Email</label>
                                <input type="text" name="email" class="form-control" value="<?php echo e($users->email); ?>">

                                <?php if($errors->has('email')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('email')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            </div>
                            <div class="row">
                            <div class="col-md-6 col">
                                <label>Jenis Kelamin</label>
                                
                                <select name="jk" class="form-control">
                                    <option value="L" <?php echo e($users->jk == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                                    <option value="P" <?php echo e($users->jk == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                                </select>

                                <?php if($errors->has('jk')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('jk')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>

                            <div class="col-md-6 col">
                                <label>Alamat</label>
                                <input type="text" name="alamat" class="form-control" value="<?php echo e($users->alamat); ?>">

                                <?php if($errors->has('alamat')): ?>
                                    <div class="text-danger">
                                        <?php echo e($errors->first('alamat')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            </div>
                            <br />
                            <br />
                            <div class="col">
                                <a href="<?php echo e(route('change', ['id' => $users->id])); ?>" style="float:left"
                                    class="btn btn-danger">Ubah Password</a>
                                <button type="submit" style="float:right" class="btn btn-success">Simpan</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/layouts/profil.blade.php ENDPATH**/ ?>