<?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
<li>
    <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Dashboard')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('kategori')); ?>"><?php echo e(__('Rubik')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('subkategori')); ?>"><?php echo e(__('Kategori')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('user')); ?>"><?php echo e(__('User')); ?></a>
</li>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('redaktur')): ?>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Dashboard')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('publish')); ?>"><?php echo e(__('Publish')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('myartikel')); ?>"><?php echo e(__('My Artikel')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('video')); ?>"><?php echo e(__('Video')); ?></a>
</li>
<?php endif; ?>

<?php if(auth()->check() && auth()->user()->hasRole('jurnalis')): ?>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Dashboard')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('publish.jurnalis')); ?>"><?php echo e(__('Publish')); ?></a>
</li>
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('artikelredaktur.add')); ?>"><?php echo e(__('Add Artikel')); ?></a>
</li>
<?php endif; ?>


<?php /**PATH /atad/web-dinamika/wishlist/resources/views/layouts/menu.blade.php ENDPATH**/ ?>