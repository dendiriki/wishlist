<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-header text-center">
                KTP
            </div>
            <div class="card-body" style="margin:20px">

                <form method="post" action="#">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('PUT')); ?>


                    
                    <br />
                    <img src="<?php echo e(asset('uploads/' . $us->ktp)); ?>" style="height:500px;" />
                    <br />
                    <br />
            </div>

        </div>
        <br />
        

        <a href="<?php echo e(route('user')); ?>" style="float:left" class="btn btn-primary">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/admin/detail-user.blade.php ENDPATH**/ ?>