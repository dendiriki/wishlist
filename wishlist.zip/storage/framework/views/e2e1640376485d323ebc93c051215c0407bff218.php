<?php $__env->startSection('content'); ?>
    <div class="row" style="margin: 20px; grid-row-gap:20px">
        <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-sm-6 col-12 mb-2">
                <a href="<?php echo e(route('artikel-wishlist', $artk->id)); ?>" style="text-decoration: none; color: black">
                    <div class="card">
                        <img class="card-img-top" src="<?php echo e(asset('uploads/' . $artk->thumb)); ?>"
                            style="height: 15rem; object-fit: cover" alt="<?php echo e($artk->thumb); ?>">
                        <div class="card-body">
                            <small
                                class="badge rounded-pill px-4 py-2 mb-3 bg-pink text-white"><?php echo e($artk->artikelsubkategori[0]->subkategori->subkategories); ?></small>
                            <h5 class="card-title"><?php echo e($artk->judul); ?></h5>
                        </div>
                    </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wishlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/halaman.blade.php ENDPATH**/ ?>