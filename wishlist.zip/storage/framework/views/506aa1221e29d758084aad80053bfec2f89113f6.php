<?php $__env->startSection('content'); ?>
    <div class="container my-5">
        <div class="row">
            <div class="col">
                <h3 class="text-center"><?php echo e($artikel->judul); ?></h3>
                <p class="text-center mb-0" style="font-size: 0.8rem"><?php echo e($artikel->artikelstatus[0]->updated_at); ?></p>
                <p class="text-center" style="font-size: 0.8rem">By <?php echo e($artikel->user->name); ?></p>
                <img style="width:650px; height:400px ; margin-left:230px; object-fit: cover" class="text-center mb-3"
                    style="max-width: 100%" src="<?php echo e(asset('uploads/' . $artikel->thumb)); ?>" />
                <?php echo $artikel->isi; ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wishlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/post.blade.php ENDPATH**/ ?>