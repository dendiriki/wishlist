<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-header text-center">
                Video
            </div>
            <div class="card-body">
                <a href="<?php echo e(route('fetch-youtube')); ?>" class="btn btn-primary">Fetch Data from Youtube API</a>
                <br />
                <br />
                <table class="table table-bordered table-hover table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Thumbnail</th>
                            <th style="width: 12%">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <b><?php echo $item->nama; ?></b><br>
                                    <?php echo $item->description; ?>

                                </td>
                                <td><img src="<?php echo e($item->thumbnail); ?>" style="height: 10rem" /></td>
                                <td>
                                    <a href="<?php echo e($item->url); ?>"
                                        class="btn btn-primary" target="_blank">Go to Link</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($video->links("pagination::bootstrap-4")); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/admin/video.blade.php ENDPATH**/ ?>