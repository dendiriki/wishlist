<table class="table table-bordered table-hover table-striped">
    <thead>
        <tr>
            <th>No</th>
            <th>Judul Artikel</th>
            <th>Tanggal Submit</th>
            <th>Penulis</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $artikelstatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td> <?php if(isset($a->artikel)): ?>
                        <a href="<?php echo e(route('read', ['id' => $a->id])); ?>" style="color: #000"><?php echo e($a->artikel->judul); ?></a>
                    <?php endif; ?>
                </td>
                <td><?php if(isset($a->artikel)): ?>
                        <?php echo e($a->artikel->updated_at); ?>

                    <?php endif; ?></td>
                </td>
                <td>
                    <?php if(isset($a->artikel)): ?>
                        <?php echo e($a->artikel->user->name); ?>

                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('read', ['id' => $a->id])); ?>" class="btn btn-success">Detail</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /atad/web-dinamika/wishlist/resources/views/redaktur/dashboard-redaktur.blade.php ENDPATH**/ ?>