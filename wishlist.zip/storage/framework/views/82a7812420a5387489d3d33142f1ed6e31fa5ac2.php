<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            <?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-header">
                Dashboard
            </div>
            <div class="card-body">
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <?php echo e(__('You are logged in!')); ?>

                <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('redaktur')): ?>
                <?php echo $__env->make('redaktur.dashboard-redaktur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php if(auth()->check() && auth()->user()->hasRole('jurnalis')): ?>
                <?php echo $__env->make('jurnalis.dashboard-jurnalis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/home.blade.php ENDPATH**/ ?>