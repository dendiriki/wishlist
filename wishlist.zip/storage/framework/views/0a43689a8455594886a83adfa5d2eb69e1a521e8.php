<?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div id="carouselId" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselId" data-slide-to="0" class="active"></li>
                <li data-target="#carouselId" data-slide-to="1"></li>
                <li data-target="#carouselId" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner" role="listbox">
                <?php $__currentLoopData = $art; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    
                    <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                        <div class="d-flex">
                            <img class="" src="<?php echo e(asset('uploads/' . $a->thumb)); ?>"
                                style="height: 25rem; width: 70%; object-fit: cover" alt="First slide">
                            <div class="card bg-purple" style="width: 30%; height: 25rem">
                                <div class="card-body">
                                    <div style="width: 100%; height: 100%; border: 1px solid white">
                                        <a href="<?php echo e(route('artikel-wishlist', $a->id)); ?>"
                                            style="text-decoration: none; color: black">
                                            <h4><?php echo e($a->judul); ?></h4>
                                            <p><?php echo substr(strip_tags($a->isi), 0, 50); ?>..</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <a class="carousel-control-prev" href="#carouselId" role="button" data-slide="prev">
                <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
                <img src="<?php echo e(asset('assets/icons/prev-green.png')); ?>" width="50" />
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselId" role="button" data-slide="next">
                <img src="<?php echo e(asset('assets/icons/next-green.png')); ?>" width="50" />
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <div class="container-fluid p-5" style="background-image: url('<?php echo e(asset('assets/backgrounds/Frame 2.png')); ?>'); background-size: cover; background-position: center">
        <div class="polygon-test mb-3 mx-auto bg-green d-flex align-items-center justify-content-center"
            style="max-width: 18rem; height: 5rem;">
            <h1 class="title-text">Latest News.</h1>
        </div>
        <div class="row">
            <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-6 col-12 mb-2">
                    <a href="<?php echo e(route('artikel-wishlist', $artk->id)); ?>" style="text-decoration: none; color: black">
                        <div class="card">
                            
                            <img class="card-img-top" src="<?php echo e(asset('uploads/' . $artk->thumb)); ?>"
                                style="height: 10rem; object-fit: cover" alt="<?php echo e($artk->thumb); ?>">
                            <div class="card-body">
                                <small
                                    class="badge rounded-pill px-4 py-2 mb-3 bg-pink text-white"><?php echo e($artk->artikelsubkategori[0]->subkategori->subkategories); ?></small>
                                <h5 class="card-title"><?php echo e($artk->judul); ?></h5>
                                <p><?php echo substr(strip_tags($artk->isi), 0, 50); ?>..</p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row mt-3 justify-content-center">
            <a href="#"><img class="clickable" src="<?php echo e(asset('assets/icons/prev-pink.png')); ?>" width="50" /></a>
            <a href="#"><img class="clickable" src="<?php echo e(asset('assets/icons/next-pink.png')); ?>" width="50" /></a>
        </div>
    </div>
    
    <div class="container-fluid p-5" style="background-image: url('<?php echo e(asset('assets/backgrounds/Frame 3 (1).png')); ?>'); background-size:cover; background-position: center">
        <div class="row">
            <div class="col-md-3 col-12 m-auto">
                <div class="polygon-test mb-3 mx-auto bg-green d-flex align-items-center justify-content-center"
                    style="max-width: 10rem; height: 6rem;">
                    <h1 class="title-text">Video.</h1>
                </div>
            </div>
            <div class="col-md-9 col-12 text-center">
                <div class="row">
                    <?php for($index = 0; $index < $youtube->count(); $index++): ?>
                        <div class="col-md-4 col-12">
                            <iframe class="w-100" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"
                                type="text/html"
                                src="https://www.youtube.com/embed/<?php echo e($youtube[$index]->videoId); ?>"></iframe>
                            <p style="font-size: 0.85rem"><?php echo $youtube[$index]->nama; ?></p>
                        </div>
                        <?php if(($index+1) % 3 == 0): ?>
                </div>
                <div class="row">
                    <?php endif; ?>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        <div class="row mt-3 justify-content-center">
            <a href="#"><img src="<?php echo e(asset('assets/icons/prev-yellow.png')); ?>" width="50" /></a>
            <a href="#"><img src="<?php echo e(asset('assets/icons/next-yellow.png')); ?>" width="50" /></a>
        </div>
    </div>
    
    <div class="container-fluid p-5" style="background-image: url('<?php echo e(asset('assets/backgrounds/Frame 4 (1).png')); ?>'); background-size: cover; background-position: center">
        <div class="polygon-test mb-3 mx-auto bg-green d-flex align-items-center justify-content-center"
            style="max-width: 12rem; height: 7rem;">
            <h2 class="title-text">Wishlist<br>Friend.</h2>
        </div>
        <!-- <div class="row mx-4 my-4 border border-success"> -->
        <div class="row mx-4 my-4 justify-content-center">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jrnls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                    <img style="border: 1px solid #000000; width: 150px; height: 150px; overflow: hidden; border-radius: 50%; object-fit: cover; display: block; margin-right: auto; margin-left: auto;"
                        src="<?php echo e($jrnls->foto != '' ? asset('uploads/' . $jrnls->foto) : asset('assets/images/cowok-removebg-preview.png')); ?>">
                    <p style="text-align:center" class="mb-0">Nama : <?php echo e($jrnls->name); ?></p>
                    
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- </div> -->
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.wishlist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/start.blade.php ENDPATH**/ ?>