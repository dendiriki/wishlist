<div class="card-body">
    <table class="table table-bordered table-hover table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul Artikel</th>
                <th>Tanggal Submit</th>
                <th>Status</th>
                <th>Keterangan</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php if($a->artikelstatus[0]->id_status == 3 || $a->artikelstatus[0]->id_status == 4): ?>
                            <a href="<?php echo e(route('artikelredaktur.edit', ['id' => $a->id, 'id_artikel' => $a->artikelstatus[0]->id_artikel])); ?>"
                                style="color: #000;"><?php echo e($a->judul); ?></a>
                        <?php else: ?>
                            <?php echo e($a->judul); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($a->updated_at); ?></td>
                    <td>
                        <?php if(isset($a->artikelstatus[0])): ?>
                            <?php echo e($a->artikelstatus[0]->status->statuses); ?>

                        <?php endif; ?>
                    </td>
                    <td><?php echo e($a->Keterangan); ?></td>
                    <td>
                        <?php if($a->artikelstatus[0]->id_status == 3 || $a->artikelstatus[0]->id_status == 4): ?>
                            <a href="<?php echo e(route('artikelredaktur.edit', ['id' => $a->id, 'id_artikel' => $a->artikelstatus[0]->id_artikel])); ?>"
                                class="btn btn-warning">Edit</a>
                        <?php else: ?>
                            <a href="#" class="btn btn-secondary">Edit</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH /atad/web-dinamika/wishlist/resources/views/jurnalis/dashboard-jurnalis.blade.php ENDPATH**/ ?>