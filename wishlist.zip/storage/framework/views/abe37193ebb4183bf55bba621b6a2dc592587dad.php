<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.select2-single').select2({
                theme: 'bootstrap4',
            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card mt-5">
            
            <div class="card-body">
                <a href="<?php echo e(route('myartikel')); ?>" class="btn btn-primary">Back</a>
                <br />
                <br />

                <form method="post" action="<?php echo e(route('redaktur.draft')); ?>" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>


                    <div class="row">

                        

                        <?php if(auth()->check() && auth()->user()->hasRole('redaktur')): ?>
                        <div class="col">
                            <label>Jenis</label>
                            <select class="form-control select2-single" name="id_headline">
                                <?php $__empty_1 = true; $__currentLoopData = $headline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($h->id); ?>"><?php echo e($h->highlight); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value=""> </option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <div class="col">
                            <label>Kategori</label>
                            <select class="form-control select2-single" name="id_subkategori">
                                <?php $__empty_1 = true; $__currentLoopData = $subkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($k->id); ?>"><?php echo e($k->subkategories); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value=""> </option>
                                <?php endif; ?>
                            </select>

                        </div>


                        <?php if($errors->has('id_subkategories')): ?>
                            <div class="text-danger">
                                <?php echo e($errors->first('id_subkategories')); ?>

                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="row">


                        <div class="col">
                            <label>Judul</label>
                            <input type="text" name="judul" class="form-control" placeholder="Judul">

                            <?php if($errors->has('judul')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('judul')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col">
                            <label>Thumbnail</label><br>
                            <input type="file" name="thumb">


                            <?php if($errors->has('thumb')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('thumb')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col">
                            <label>Isi</label>
                            <textarea id="isi" name="isi" class="" placeholder="Isi"></textarea>
            
                            <?php if($errors->has('isi')): ?>
                                <div class="text-danger">
                                    <?php echo e($errors->first('isi')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
        
                    <div class="form-group mt-3">
                        <?php if(auth()->check() && auth()->user()->hasRole('redaktur')): ?>
                        <button type="submit" style="" class="btn btn-warning">Draft</button>
                        <button formaction="<?php echo e(route('artikelredaktur.new')); ?>" type="submit" style="float:Right"
                            class="btn btn-success">Kirim</button>
                        <?php endif; ?>
                        <?php if(auth()->check() && auth()->user()->hasRole('jurnalis')): ?>
                        <button formaction="<?php echo e(route('artikeljurnalis.newDraft')); ?>" type="submit" style=""
                            class="btn btn-warning">Draft</button>
                        <button formaction="<?php echo e(route('artikeljurnalis.new')); ?>" type="submit" style="float:Right"
                            class="btn btn-success">Kirim</button>
                        <?php endif; ?>
                    </div>
            </div>


            </form>

        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /atad/web-dinamika/wishlist/resources/views/redaktur/artikel-add.blade.php ENDPATH**/ ?>