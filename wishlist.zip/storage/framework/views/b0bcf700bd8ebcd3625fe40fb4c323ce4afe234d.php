<header role="banner">
    <img id="logo-main" src="<?php echo e(asset('assets/images/logo_wishlist.png')); ?>" width="200" alt="Logo Thing main logo">
    <div class="d-none d-lg-block d-xl-block">
        <div class="d-flex social-media-nav">
            <a class="nav-link" href="https://www.facebook.com/universitasdinamika/" target="_blank"><i
                    class="fab fa-facebook-f text-pink"></i></a>
            <a class="nav-link" href="https://www.youtube.com/user/stikomsurabaya" target="_blank"><i
                    class="fab fa-youtube text-pink"></i></a>
            <a class="nav-link" href="https://twitter.com/undikasurabaya" target="_blank"><i
                    class="fab fa-twitter text-pink"></i></a>
            <a class="nav-link" href="https://www.instagram.com/universitasdinamika" target="_blank"><i
                    class="fab fa-instagram text-pink"></i></a>
        </div>
    </div>
    <nav class="navbar navbar-expand-sm navbar-light bg-pink">
        <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId"
            aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation"><i
                class="fas fa-bars"></i></button>
        <div class="collapse navbar-collapse" id="collapsibleNavId">
            <ul class="navbar-nav mx-auto mt-2 mt-lg-0">
                <!-- active link -->
                <li class="nav-item mx-md-4 active">
                    
                    <a class="nav-link text-white" href="<?php echo e(route('wishlist')); ?>">HOME <span class="sr-only">(current)</span></a>
                </li>
                <!-- end active link -->
                <!-- <li class="nav-item mx-5">
                    <a class="nav-link" href="#">ISSUE</a>
                </li> -->
                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->subkategori->count() != 0): ?>
                        <li class="nav-item mx-md-4 dropdown">
                            <a class="nav-link dropdown text-white" href="#" id="dropdownId" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false"><?php echo e($item->kategories); ?></a>
                            <div class="dropdown-menu" aria-labelledby="dropdownId">
                                <?php $__currentLoopData = $item->subkategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="dropdown-item"
                                        href="<?php echo e(route('halaman', ['id' => $subs->id])); ?>"><?php echo e($subs->subkategories); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </li>
                    <?php else: ?>
                        
                        <li class="nav-item mx-md-4">
                            <a class="nav-link text-white"
                                href="<?php echo e(route('halaman_baru', ['id' => $item->id])); ?>"><?php echo e($item->kategories); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <li class="nav-item mx-md-4">
                    <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><i class="fas fa-key"></i></a>
                </li>
            </ul>

        </div>
    </nav>
</header><!-- header role="banner" -->
<?php /**PATH /atad/web-dinamika/wishlist/resources/views/layouts/components/header.blade.php ENDPATH**/ ?>